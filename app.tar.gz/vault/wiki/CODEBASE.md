# Codebase Map

npm workspaces monorepo at `/home/${username}/websites/${sandboxId}/public_html`. The web app ships standalone. Call `enable_pocketbase_integration` to add a database, or `enable_api_server_integration` to add an Express backend — each tool appends its own `## apps/<service>` section to this file.

## apps/web (React + Vite + Tailwind + shadcn/ui, port 3000)

Located at apps/web/. Run: `cd apps/web && npm run dev` (auto-started by the sandbox supervisor).
src/main.jsx — entry point, mounts <App />
src/App.jsx — React Router, all routes defined here
src/index.css — Tailwind theme, CSS variables, luxury Morocco design system with terracotta/saffron palette, Fraunces + DM Sans fonts, zellige patterns
src/pages/HomePage.jsx — "/" route, high-converting luxury homepage with 17 sections (hero, benefits, tours, luxury, testimonials, reviews, trust badges, awards, booking process, map, WhatsApp banner, lead form, newsletter, FAQ)
src/pages/pages.jsx — all remaining pages (About, Tours, Luxury Tours, Private Tours, Desert Tours, Day Trips, Airport Transfers, Private Drivers, Custom Tours, Destinations, Blog, Travel Guide, Reviews, Gallery, FAQ, Contact) with SEO, itineraries, pricing, galleries, forms, maps, testimonials, CTAs
src/data/site.js — central config: site metadata, real contact info (+212 606-066518, contact-pro@moroccotripholidays.com, Marrakech address), tour data, images, testimonials (real TripAdvisor reviews), FAQs, pricing, trust elements
src/components/site.jsx — shared components: Layout, Navigation, Footer, Hero, TourCard, BookingForm, LeadForm, NewsletterForm, WhatsAppBanner, TrustBadges, TestimonialSection, GoogleReviewsWidget, MapEmbed, TourGallery, PricingTable, FAQSection, CTAButtons
src/components/ScrollToTop.jsx — resets scroll on route change
src/components/ui/ — shadcn/ui primitives — import from `@/components/ui/<name>`, do not edit the files
src/hooks/use-mobile.jsx — mobile breakpoint detection
src/hooks/use-toast.js — toast notifications
src/lib/utils.js — cn() Tailwind class merge
vault/wiki/skills/design/SKILL.md — frontend craft, styling, typography, motion, and shadcn policy for UI surfaces.
apps/web/plugins/session-journal/ — infrastructure, DO NOT edit. Vite dev plugin injects the browser session journal client; events go over HMR (`import.meta.hot.send('session-journal:event', …)`); the plugin arranges persistence under `vault/temp/SESSION_JOURNAL.md`.
Routes: / → HomePage, /about → About, /tours → Tours, /luxury-tours → Luxury Tours, /private-tours → Private Tours, /desert-tours → Desert Tours, /day-trips → Day Trips, /airport-transfers → Airport Transfers, /private-drivers → Private Drivers, /custom-tours → Custom Tours, /destinations → Destinations, /blog → Blog, /travel-guide → Travel Guide, /reviews → Reviews, /gallery → Gallery, /faq → FAQ, /contact → Contact
